import { google } from 'googleapis';

const SPREADSHEET_ID = process.env.GOOGLE_SHEETS_ID || '1n5C0-BBOGVR9JrCTCiwECYecVny8AFlxLFXbwBjMw3Y';
const GEMINI_API_KEY = process.env.GEMINI_API_KEY;

const GCS_BUCKET_NAME = process.env.GCS_BUCKET_NAME || 'sst-documentos-empleados';
const GCS_PROJECT_ID = process.env.GCS_PROJECT_ID || 'sg-sst-501720';

const auth = new google.auth.GoogleAuth({
  keyFile: process.env.GOOGLE_SHEETS_KEY_PATH || '/home/syso_sergiojimenez/credentials/service-account.json',
  scopes: [
    'https://www.googleapis.com/auth/spreadsheets',
    'https://www.googleapis.com/auth/devstorage.read_write',
  ],
});

const sheets = google.sheets({ version: 'v4', auth });

// Cache para sheetId
let cachedSheetId: number | null = null;

// Obtener sheetId de "NOMINA DE PERSONAL"
async function getSheetId(): Promise<number> {
  if (cachedSheetId !== null) return cachedSheetId;
  
  const response = await sheets.spreadsheets.get({
    spreadsheetId: SPREADSHEET_ID,
  });
  
  const sheet = response.data.sheets?.find(s => s.properties?.title === 'NOMINA DE PERSONAL');
  if (!sheet || !sheet.properties?.sheetId) {
    throw new Error('Hoja "NOMINA DE PERSONAL" no encontrada');
  }
  
  cachedSheetId = sheet.properties.sheetId;
  console.log('📄 Sheet ID de NOMINA DE PERSONAL:', cachedSheetId);
  return cachedSheetId;
}

// ========== GOOGLE CLOUD STORAGE ==========
export async function subirPDFAGCS(
  base64PDF: string,
  nombreArchivo: string,
  mimeType: string = 'application/pdf'
): Promise<string> {
  try {
    console.log('📤 Subiendo PDF a GCS...');
    const client = await auth.getClient();
    const token = await client.getAccessToken();

    if (!token.token) {
      throw new Error('No se pudo obtener token de acceso para GCS');
    }

    const buffer = Buffer.from(base64PDF, 'base64');

    const uploadUrl = `https://storage.googleapis.com/upload/storage/v1/b/${GCS_BUCKET_NAME}/o?uploadType=media&name=${encodeURIComponent(nombreArchivo)}`;

    const response = await fetch(uploadUrl, {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer ' + token.token,
        'Content-Type': mimeType,
      },
      body: buffer,
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`GCS upload error: ${response.status} - ${errorText}`);
    }

    const result = await response.json();

    const aclUrl = `https://storage.googleapis.com/storage/v1/b/${GCS_BUCKET_NAME}/o/${encodeURIComponent(nombreArchivo)}/acl`;

    const aclResponse = await fetch(aclUrl, {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer ' + token.token,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        entity: 'allUsers',
        role: 'READER',
      }),
    });

    if (!aclResponse.ok) {
      console.warn('⚠️ No se pudo hacer público el objeto:', await aclResponse.text());
    }

    const publicUrl = `https://storage.googleapis.com/${GCS_BUCKET_NAME}/${encodeURIComponent(nombreArchivo)}`;

    console.log('✅ PDF subido a GCS:', publicUrl);
    return publicUrl;
  } catch (error) {
    console.error('❌ Error subiendo a GCS:', error);
    throw new Error('Error al subir PDF a GCS: ' + (error as Error).message);
  }
}

// ========== GEMINI AI ==========
export interface DatosExtraidosPDF {
  nroDocumento: string;
  nombres: string;
  apellidos: string;
  fechaNacimiento: string;
  lugarNacimiento: string;
  sexo: string;
  estadoCivil: string;
  direccion: string;
  telefono: string;
  email: string;
  tipoSangre: string;
  cargo: string;
  empresa: string;
  obra: string;
  contactoEmergencia: string;
  telefonoEmergencia: string;
  [key: string]: string;
}

export async function extraerDatosConGemini(
  base64PDF: string,
  mimeType: string = 'application/pdf'
): Promise<DatosExtraidosPDF> {
  if (!GEMINI_API_KEY) {
    throw new Error('GEMINI_API_KEY no configurada en .env');
  }

  console.log('🤖 Usando gemini-2.5-flash...');
  console.log('📄 Base64 length:', base64PDF.length);

  if (!base64PDF || base64PDF.length < 100) {
    throw new Error('PDF vacío o base64 inválido. Length: ' + (base64PDF?.length || 0));
  }

  const prompt = `Analiza este documento PDF que contiene una ficha o cédula de un trabajador. 
Extrae TODOS los datos personales y laborales que encuentres.
Responde ÚNICAMENTE en formato JSON con esta estructura exacta:

{
  "nroDocumento": "número de documento de identidad",
  "nombres": "nombres completos",
  "apellidos": "apellidos completos",
  "fechaNacimiento": "fecha de nacimiento (DD/MM/YYYY)",
  "lugarNacimiento": "ciudad/departamento de nacimiento",
  "sexo": "M o F",
  "estadoCivil": "soltero, casado, divorciado, etc",
  "direccion": "dirección completa",
  "telefono": "teléfono celular",
  "email": "correo electrónico",
  "tipoSangre": "tipo de sangre (A+, O-, etc)",
  "cargo": "cargo o puesto",
  "empresa": "nombre de la empresa",
  "obra": "obra o proyecto asignado",
  "contactoEmergencia": "nombre contacto de emergencia",
  "telefonoEmergencia": "teléfono de emergencia"
}

Si algún dato no está en el documento, usa string vacío "".
NO incluyas explicaciones, SOLO el JSON.`;

  try {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1/models/gemini-2.5-flash:generateContent?key=${GEMINI_API_KEY}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{
            parts: [
              { text: prompt },
              {
                inline_data: {
                  mime_type: mimeType,
                  data: base64PDF
                }
              }
            ]
          }],
          generationConfig: {
            temperature: 0.1,
            maxOutputTokens: 2048,
          }
        })
      }
    );

    console.log('📡 Gemini status:', response.status);

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Gemini API error: ${response.status} - ${errorText}`);
    }

    const result = await response.json();
    
    if (result.error) {
      throw new Error(`Gemini error: ${result.error.message || JSON.stringify(result.error)}`);
    }

    if (!result.candidates || !result.candidates[0]) {
      throw new Error('Gemini no devolvió candidates en la respuesta');
    }

    const candidate = result.candidates[0];
    
    if (!candidate.content || !candidate.content.parts) {
      throw new Error('Gemini no devolvió content.parts en la respuesta');
    }

    const text = candidate.content.parts[0]?.text || '';
    
    if (!text) {
      throw new Error('Gemini no devolvió texto en la respuesta');
    }

    let datos: any = null;
    let extractionMethod = '';

    const markdownMatch = text.match(/```(?:json)?\s*([\s\S]*?)\s*```/);
    if (markdownMatch) {
      try {
        datos = JSON.parse(markdownMatch[1].trim());
        extractionMethod = 'markdown code block';
      } catch (e) {
        console.log('📝 Método markdown falló, intentando otro...');
      }
    }

    if (!datos) {
      const jsonMatch = text.match(/\{[\s\S]*?\}/);
      if (jsonMatch) {
        try {
          datos = JSON.parse(jsonMatch[0]);
          extractionMethod = 'raw JSON object';
        } catch (e) {
          console.log('📝 Método raw JSON falló, intentando otro...');
        }
      }
    }

    if (!datos) {
      try {
        const trimmed = text.trim();
        if (trimmed.startsWith('{') && trimmed.endsWith('}')) {
          datos = JSON.parse(trimmed);
          extractionMethod = 'full text JSON';
        }
      } catch (e) {
        console.log('📝 Método full text falló...');
      }
    }

    if (!datos) {
      throw new Error('No se pudo extraer JSON de la respuesta de Gemini');
    }

    console.log('✅ JSON extraído via:', extractionMethod);

    if (!datos.nombres && !datos.apellidos && !datos.nroDocumento) {
      throw new Error('Gemini no pudo extraer datos del documento');
    }

    return datos;
  } catch (error) {
    console.error('❌ Error en Gemini:', error);
    throw error;
  }
}

// ========== EMPLEADOS ==========
export interface Empleado {
  nroDocumento: string;
  nombres: string;
  apellidos: string;
  cargo: string;
  obra: string;
  empresa: string;
  telefonoCelular: string;
  email: string;
  scanDocumentos?: string;
}

export async function getEmpleados(): Promise<Empleado[]> {
  try {
    const response = await sheets.spreadsheets.values.get({
      spreadsheetId: SPREADSHEET_ID,
      range: 'NOMINA DE PERSONAL!A2:BC',
    });

    const rows = response.data.values || [];
    return rows.map(row => ({
      nroDocumento: row[0] || '',
      nombres: row[5] || '',
      apellidos: row[6] || '',
      cargo: row[44] || '',
      obra: row[3] || '',
      empresa: row[43] || '',
      telefonoCelular: row[26] || '',
      email: row[28] || '',
      scanDocumentos: row[53] || '',
    }));
  } catch (error) {
    console.error('Error reading empleados:', error);
    return [];
  }
}

export async function getEmpleadoByDocumento(nroDocumento: string): Promise<Empleado | null> {
  const empleados = await getEmpleados();
  return empleados.find(e => e.nroDocumento === nroDocumento) || null;
}

export async function getEmpleadosByObra(obra: string): Promise<Empleado[]> {
  const empleados = await getEmpleados();
  return empleados.filter(e => e.obra === obra);
}

// Buscar fila de empleado por documento
export async function buscarFilaEmpleado(nroDocumento: string): Promise<number> {
  const response = await sheets.spreadsheets.values.get({
    spreadsheetId: SPREADSHEET_ID,
    range: 'NOMINA DE PERSONAL!A2:A',
  });

  const rows = response.data.values || [];
  const rowIndex = rows.findIndex(row => row[0] === nroDocumento);

  if (rowIndex === -1) {
    throw new Error(`Empleado con documento ${nroDocumento} no encontrado`);
  }

  return rowIndex + 2; // +2 porque empezamos en A2
}

export async function createEmpleado(empleado: {
  nroDocumento: string;
  nombres: string;
  apellidos: string;
  cargo: string;
  obra: string;
  empresa: string;
  telefonoCelular: string;
  email: string;
  scanDocumentos?: string;
}): Promise<string> {
  const now = new Date().toISOString();
  
  const row = [
    empleado.nroDocumento,        // A  (0)
    now,                          // B  (1)
    empleado.email,               // C  (2)
    empleado.obra,                // D  (3)
    'CC',                         // E  (4)
    empleado.nombres,             // F  (5)
    empleado.apellidos,           // G  (6)
    '',                           // H  (7)
    '',                           // I  (8)
    '',                           // J  (9)
    '',                           // K  (10)
    '',                           // L  (11)
    '',                           // M  (12)
    '',                           // N  (13)
    '',                           // O  (14)
    '',                           // P  (15)
    '',                           // Q  (16)
    '',                           // R  (17)
    '',                           // S  (18)
    '',                           // T  (19)
    '',                           // U  (20)
    '',                           // V  (21)
    '',                           // W  (22)
    '',                           // X  (23)
    '',                           // Y  (24)
    '',                           // Z  (25)
    '',                           // AA (26)
    empleado.telefonoCelular,     // AB (27)
    '',                           // AC (28)
    empleado.email,               // AD (29)
    '',                           // AE (30)
    '',                           // AF (31)
    '',                           // AG (32)
    '',                           // AH (33)
    '',                           // AI (34)
    '',                           // AJ (35)
    '',                           // AK (36)
    '',                           // AL (37)
    '',                           // AM (38)
    '',                           // AN (39)
    '',                           // AO (40)
    '',                           // AP (41)
    '',                           // AQ (42)
    empleado.empresa,             // AR (43)
    empleado.cargo,               // AS (44)
    '',                           // AT (45)
    '',                           // AU (46)
    '',                           // AV (47)
    '',                           // AW (48)
    '',                           // AX (49)
    '',                           // AY (50)
    '',                           // AZ (51)
    '',                           // BA (52)
    empleado.scanDocumentos || '', // BB (53)
  ];
  
  await sheets.spreadsheets.values.append({
    spreadsheetId: SPREADSHEET_ID,
    range: 'NOMINA DE PERSONAL!A2:BB',
    valueInputOption: 'RAW',
    requestBody: {
      values: [row],
    },
  });
  
  return empleado.nroDocumento;
}

// ACTUALIZAR empleado existente
export async function actualizarEmpleado(
  nroDocumento: string,
  datos: Partial<Empleado>
): Promise<void> {
  const fila = await buscarFilaEmpleado(nroDocumento);
  
  console.log('📝 Actualizando empleado en fila:', fila);
  console.log('📝 Datos a actualizar:', JSON.stringify(datos, null, 2));

  const updates: { range: string; value: string }[] = [];

  if (datos.nombres !== undefined) {
    updates.push({ range: `NOMINA DE PERSONAL!F${fila}`, value: datos.nombres });
  }
  if (datos.apellidos !== undefined) {
    updates.push({ range: `NOMINA DE PERSONAL!G${fila}`, value: datos.apellidos });
  }
  if (datos.cargo !== undefined) {
    updates.push({ range: `NOMINA DE PERSONAL!AS${fila}`, value: datos.cargo });
  }
  if (datos.obra !== undefined) {
    updates.push({ range: `NOMINA DE PERSONAL!D${fila}`, value: datos.obra });
  }
  if (datos.empresa !== undefined) {
    updates.push({ range: `NOMINA DE PERSONAL!AR${fila}`, value: datos.empresa });
  }
  if (datos.telefonoCelular !== undefined) {
    updates.push({ range: `NOMINA DE PERSONAL!AB${fila}`, value: datos.telefonoCelular });
  }
  if (datos.email !== undefined) {
    updates.push({ range: `NOMINA DE PERSONAL!AD${fila}`, value: datos.email });
  }
  if (datos.scanDocumentos !== undefined) {
    updates.push({ range: `NOMINA DE PERSONAL!BB${fila}`, value: datos.scanDocumentos });
  }

  if (updates.length === 0) {
    console.log('⚠️ No hay campos para actualizar');
    return;
  }

  const data = updates.map(u => ({
    range: u.range,
    values: [[u.value]],
  }));

  await sheets.spreadsheets.values.batchUpdate({
    spreadsheetId: SPREADSHEET_ID,
    requestBody: {
      valueInputOption: 'RAW',
      data: data,
    },
  });

  console.log('✅ Empleado actualizado:', nroDocumento);
}

// ELIMINAR empleado - usar clear en lugar de deleteDimension para evitar problemas de sheetId
export async function eliminarEmpleado(nroDocumento: string): Promise<void> {
  const fila = await buscarFilaEmpleado(nroDocumento);
  
  console.log('🗑️ Eliminando empleado en fila:', fila);

  // Obtener sheetId correcto
  const sheetId = await getSheetId();

  // Eliminar la fila completa usando deleteDimension
  await sheets.spreadsheets.batchUpdate({
    spreadsheetId: SPREADSHEET_ID,
    requestBody: {
      requests: [
        {
          deleteDimension: {
            range: {
              sheetId: sheetId,
              dimension: 'ROWS',
              startIndex: fila - 1, // 0-based index
              endIndex: fila, // fila exclusiva
            },
          },
        },
      ],
    },
  });

  console.log('✅ Empleado eliminado:', nroDocumento);
}

export async function actualizarScanDocumentos(
  nroDocumento: string,
  scanUrl: string
): Promise<void> {
  const fila = await buscarFilaEmpleado(nroDocumento);
  
  await sheets.spreadsheets.values.update({
    spreadsheetId: SPREADSHEET_ID,
    range: `NOMINA DE PERSONAL!BB${fila}`,
    valueInputOption: 'RAW',
    requestBody: {
      values: [[scanUrl]],
    },
  });

  console.log('✅ SCAN_DOCUMENTOS actualizado para:', nroDocumento);
}

// ========== INCIDENTES ==========
export interface Incidente {
  id: string;
  fecha: string;
  reportadoPor: string;
  tipo: string;
  gravedad: string;
  area: string;
  descripcion: string;
  lesionado: string;
  nombreLesionado: string;
  diasPerdidos: string;
  causaInmediata: string;
  causaBasica: string;
  accionCorrectiva: string;
  estado: string;
  evidenciaUrl: string;
}

export async function getIncidentes(): Promise<Incidente[]> {
  try {
    const response = await sheets.spreadsheets.values.get({
      spreadsheetId: SPREADSHEET_ID,
      range: 'INCIDENTES!A2:O',
    });

    const rows = response.data.values || [];
    return rows.map(row => ({
      id: row[0] || '',
      fecha: row[1] || '',
      reportadoPor: row[2] || '',
      tipo: row[3] || '',
      gravedad: row[4] || '',
      area: row[5] || '',
      descripcion: row[6] || '',
      lesionado: row[7] || '',
      nombreLesionado: row[8] || '',
      diasPerdidos: row[9] || '',
      causaInmediata: row[10] || '',
      causaBasica: row[11] || '',
      accionCorrectiva: row[12] || '',
      estado: row[13] || '',
      evidenciaUrl: row[14] || '',
    }));
  } catch (error) {
    console.error('Error reading incidentes:', error);
    return [];
  }
}

export async function createIncidente(incidente: Omit<Incidente, 'id'>): Promise<string> {
  const id = `INC-${Date.now()}`;
  
  await sheets.spreadsheets.values.append({
    spreadsheetId: SPREADSHEET_ID,
    range: 'INCIDENTES!A2:O',
    valueInputOption: 'RAW',
    requestBody: {
      values: [[
        id,
        incidente.fecha,
        incidente.reportadoPor,
        incidente.tipo,
        incidente.gravedad,
        incidente.area,
        incidente.descripcion,
        incidente.lesionado,
        incidente.nombreLesionado,
        incidente.diasPerdidos,
        incidente.causaInmediata,
        incidente.causaBasica,
        incidente.accionCorrectiva,
        incidente.estado,
        incidente.evidenciaUrl,
      ]],
    },
  });
  
  return id;
}
