import 'dotenv/config';
import { Hono } from 'hono';
import { cors } from 'hono/cors';
import { serveStatic } from '@hono/node-server/serve-static';
import { appRouter } from './routers';
import { createContext } from './trpc';
import { serve } from '@hono/node-server';
import { fetchRequestHandler } from '@trpc/server/adapters/fetch';
import { extraerDatosConGemini, createEmpleado, subirPDFAGCS, actualizarEmpleado, eliminarEmpleado } from './lib/googleSheets';
import fs from 'fs';
import path from 'path';

const app = new Hono();

// CORS
app.use('/*', cors({ origin: '*' }));

// Health check
app.get('/health', (c) => c.json({ status: 'ok', timestamp: new Date().toISOString() }));

// API REST - Gemini + Guardar PDF en GCS
app.post('/api/gemini', async (c) => {
  try {
    const body = await c.req.json();
    
    if (!body.pdfBase64 || body.pdfBase64.length < 100) {
      return c.json({ error: 'PDF vacío o corrupto' }, 400);
    }

    const datos = await extraerDatosConGemini(body.pdfBase64, body.mimeType || 'application/pdf');

    const nombreArchivo = `FICHA_${datos.nroDocumento || 'SIN_DOC'}_${datos.nombres || 'SIN_NOMBRE'}_${Date.now()}.pdf`;
    const gcsUrl = await subirPDFAGCS(body.pdfBase64, nombreArchivo, body.mimeType || 'application/pdf');

    const resultado = {
      ...datos,
      scanDocumentos: gcsUrl,
    };

    return c.json({ success: true, data: resultado });
  } catch (error: any) {
    console.error('❌ /api/gemini - Error:', error.message);
    return c.json({ error: error.message }, 500);
  }
});

// API REST - Crear empleado
app.post('/api/empleados', async (c) => {
  try {
    const body = await c.req.json();
    
    const id = await createEmpleado(body);
    console.log('✅ Empleado creado:', id);
    return c.json({ success: true, id });
  } catch (error: any) {
    console.error('❌ /api/empleados - Error:', error.message);
    return c.json({ error: error.message }, 500);
  }
});

// API REST - Actualizar empleado
app.put('/api/empleados/:documento', async (c) => {
  try {
    const nroDocumento = c.req.param('documento');
    const body = await c.req.json();
    
    console.log('📥 PUT /api/empleados/:documento - Doc:', nroDocumento);
    console.log('📥 Datos:', JSON.stringify(body, null, 2));

    await actualizarEmpleado(nroDocumento, body);
    
    return c.json({ success: true, message: 'Empleado actualizado' });
  } catch (error: any) {
    console.error('❌ PUT /api/empleados - Error:', error.message);
    return c.json({ error: error.message }, 500);
  }
});

// API REST - Eliminar empleado (NUEVO)
app.delete('/api/empleados/:documento', async (c) => {
  try {
    const nroDocumento = c.req.param('documento');
    
    console.log('🗑️ DELETE /api/empleados/:documento - Doc:', nroDocumento);

    await eliminarEmpleado(nroDocumento);
    
    return c.json({ success: true, message: 'Empleado eliminado' });
  } catch (error: any) {
    console.error('❌ DELETE /api/empleados - Error:', error.message);
    return c.json({ error: error.message }, 500);
  }
});

// tRPC endpoint
app.use('/trpc/*', async (c) => {
  return fetchRequestHandler({
    endpoint: '/trpc',
    req: c.req.raw,
    router: appRouter,
    createContext: () => createContext({ req: c.req }),
    batching: { enabled: true },
  });
});

// Servir frontend estático
app.use('/*', serveStatic({ root: './dist/client' }));

// Fallback SPA
app.get('*', (c) => {
  const indexPath = path.join(process.cwd(), 'dist/client/index.html');
  if (fs.existsSync(indexPath)) {
    const content = fs.readFileSync(indexPath, 'utf-8');
    return c.html(content);
  }
  return c.text('Frontend not built. Run: npx vite build', 404);
});

serve({
  fetch: app.fetch,
  port: parseInt(process.env.PORT || '3001'),
});

console.log('🚀 Server running on http://localhost:' + (process.env.PORT || '3001'));
console.log('🪣 GCS Bucket:', process.env.GCS_BUCKET_NAME || 'sst-documentos-empleados');
console.log('📊 Google Sheets ID:', process.env.GOOGLE_SHEETS_ID || 'NO CONFIGURADO');
