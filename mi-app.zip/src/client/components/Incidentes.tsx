import React, { useState } from 'react';
import { trpc } from '../lib/trpc';
import { AlertTriangle, Plus, X } from 'lucide-react';

export default function Incidentes() {
  const [showForm, setShowForm] = useState(false);
  const { data, isLoading, refetch } = trpc.incidentes.list.useQuery();
  const createMutation = trpc.incidentes.create.useMutation({
    onSuccess: () => {
      setShowForm(false);
      refetch();
    },
  });

  if (isLoading) return <div className="text-center py-20">Cargando incidentes...</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Incidentes ({data?.length || 0})</h2>
        <button 
          onClick={() => setShowForm(!showForm)}
          className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90"
        >
          {showForm ? <X size={18} /> : <Plus size={18} />}
          {showForm ? 'Cancelar' : 'Nuevo Incidente'}
        </button>
      </div>

      {showForm && <NuevoIncidenteForm onSubmit={createMutation.mutate} isPending={createMutation.isPending} />}

      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-secondary/50">
            <tr>
              <th className="text-left px-4 py-3">ID</th>
              <th className="text-left px-4 py-3">Fecha</th>
              <th className="text-left px-4 py-3">Tipo</th>
              <th className="text-left px-4 py-3">Gravedad</th>
              <th className="text-left px-4 py-3">Área</th>
              <th className="text-left px-4 py-3">Descripción</th>
              <th className="text-left px-4 py-3">Estado</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {data?.map((incidente, index) => (
              <tr key={index} className="hover:bg-secondary/30 transition-colors">
                <td className="px-4 py-3 font-mono text-xs">{incidente.id}</td>
                <td className="px-4 py-3">{incidente.fecha}</td>
                <td className="px-4 py-3">
                  <span className={`px-2 py-1 rounded-full text-xs ${
                    incidente.tipo === 'fatal' ? 'bg-red-500/20 text-red-400' :
                    incidente.tipo === 'accidente_grave' ? 'bg-orange-500/20 text-orange-400' :
                    incidente.tipo === 'accidente_leve' ? 'bg-yellow-500/20 text-yellow-400' :
                    'bg-blue-500/20 text-blue-400'
                  }`}>
                    {incidente.tipo}
                  </span>
                </td>
                <td className="px-4 py-3">
                  <span className={`px-2 py-1 rounded-full text-xs ${
                    incidente.gravedad === 'critica' ? 'bg-red-500/20 text-red-400' :
                    incidente.gravedad === 'alta' ? 'bg-orange-500/20 text-orange-400' :
                    incidente.gravedad === 'media' ? 'bg-yellow-500/20 text-yellow-400' :
                    'bg-green-500/20 text-green-400'
                  }`}>
                    {incidente.gravedad}
                  </span>
                </td>
                <td className="px-4 py-3">{incidente.area}</td>
                <td className="px-4 py-3 max-w-xs truncate">{incidente.descripcion}</td>
                <td className="px-4 py-3">
                  <span className={`px-2 py-1 rounded-full text-xs ${
                    incidente.estado === 'cerrado' ? 'bg-green-500/20 text-green-400' :
                    incidente.estado === 'investigando' ? 'bg-yellow-500/20 text-yellow-400' :
                    'bg-blue-500/20 text-blue-400'
                  }`}>
                    {incidente.estado}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {(!data || data.length === 0) && (
          <div className="text-center py-12 text-muted-foreground">
            No hay incidentes registrados.
          </div>
        )}
      </div>
    </div>
  );
}

function NuevoIncidenteForm({ onSubmit, isPending }: any) {
  const [form, setForm] = useState({
    fecha: new Date().toISOString().split('T')[0],
    reportadoPor: 'Usuario Demo',
    tipo: 'casi_accidente' as const,
    gravedad: 'baja' as const,
    area: '',
    descripcion: '',
    lesionado: 'no' as const,
    nombreLesionado: '',
    diasPerdidos: '',
    causaInmediata: '',
    causaBasica: '',
    accionCorrectiva: '',
    estado: 'reportado' as const,
    evidenciaUrl: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(form);
  };

  return (
    <form onSubmit={handleSubmit} className="bg-card border border-border rounded-xl p-6 space-y-4">
      <h3 className="text-lg font-semibold flex items-center gap-2">
        <AlertTriangle size={20} className="text-yellow-400" />
        Nuevo Incidente
      </h3>
      
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium mb-1">Fecha</label>
          <input 
            type="date" 
            value={form.fecha}
            onChange={(e) => setForm({...form, fecha: e.target.value})}
            className="w-full bg-secondary border border-border rounded-lg px-3 py-2 text-sm"
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Tipo</label>
          <select 
            value={form.tipo}
            onChange={(e) => setForm({...form, tipo: e.target.value as any})}
            className="w-full bg-secondary border border-border rounded-lg px-3 py-2 text-sm"
          >
            <option value="casi_accidente">Casi Accidente</option>
            <option value="accidente_leve">Accidente Leve</option>
            <option value="accidente_grave">Accidente Grave</option>
            <option value="fatal">Fatal</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Gravedad</label>
          <select 
            value={form.gravedad}
            onChange={(e) => setForm({...form, gravedad: e.target.value as any})}
            className="w-full bg-secondary border border-border rounded-lg px-3 py-2 text-sm"
          >
            <option value="baja">Baja</option>
            <option value="media">Media</option>
            <option value="alta">Alta</option>
            <option value="critica">Crítica</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Área</label>
          <input 
            type="text" 
            value={form.area}
            onChange={(e) => setForm({...form, area: e.target.value})}
            className="w-full bg-secondary border border-border rounded-lg px-3 py-2 text-sm"
            placeholder="Ej: Planta de Producción A"
            required
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">Descripción</label>
        <textarea 
          value={form.descripcion}
          onChange={(e) => setForm({...form, descripcion: e.target.value})}
          className="w-full bg-secondary border border-border rounded-lg px-3 py-2 text-sm h-20 resize-none"
          placeholder="Describe el incidente..."
          required
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium mb-1">¿Hubo lesionado?</label>
          <select 
            value={form.lesionado}
            onChange={(e) => setForm({...form, lesionado: e.target.value as any})}
            className="w-full bg-secondary border border-border rounded-lg px-3 py-2 text-sm"
          >
            <option value="no">No</option>
            <option value="si">Sí</option>
          </select>
        </div>
        {form.lesionado === 'si' && (
          <div>
            <label className="block text-sm font-medium mb-1">Nombre del lesionado</label>
            <input 
              type="text" 
              value={form.nombreLesionado}
              onChange={(e) => setForm({...form, nombreLesionado: e.target.value})}
              className="w-full bg-secondary border border-border rounded-lg px-3 py-2 text-sm"
            />
          </div>
        )}
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">Causa Inmediata</label>
        <input 
          type="text" 
          value={form.causaInmediata}
          onChange={(e) => setForm({...form, causaInmediata: e.target.value})}
          className="w-full bg-secondary border border-border rounded-lg px-3 py-2 text-sm"
          placeholder="Ej: Piso mojado, cable expuesto..."
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-1">Acción Correctiva</label>
        <input 
          type="text" 
          value={form.accionCorrectiva}
          onChange={(e) => setForm({...form, accionCorrectiva: e.target.value})}
          className="w-full bg-secondary border border-border rounded-lg px-3 py-2 text-sm"
          placeholder="Ej: Colocar señalización, reparar cable..."
        />
      </div>

      <button 
        type="submit" 
        disabled={isPending}
        className="w-full bg-primary text-primary-foreground font-medium py-3 rounded-lg hover:bg-primary/90 transition-colors disabled:opacity-50"
      >
        {isPending ? 'Guardando...' : 'Guardar Incidente'}
      </button>
    </form>
  );
}
