import React, { useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { httpBatchLink } from '@trpc/client';
import { trpc } from './lib/trpc';
import Empleados from './components/Empleados';
import Incidentes from './components/Incidentes';

const queryClient = new QueryClient();
const trpcClient = trpc.createClient({
  links: [httpBatchLink({ url: '/trpc' })],
});

type View = 'empleados' | 'incidentes';

export default function App() {
  const [view, setView] = useState<View>('empleados');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  return (
    <trpc.Provider client={trpcClient} queryClient={queryClient}>
      <QueryClientProvider client={queryClient}>
        <div className="min-h-screen bg-background text-foreground flex">
          {/* Sidebar */}
          <aside 
            className={`bg-card border-r border-border flex flex-col transition-all duration-300 ${
              sidebarCollapsed ? 'w-16' : 'w-64'
            }`}
          >
            {/* Logo */}
            <div className="p-4 border-b border-border flex items-center gap-3">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center flex-shrink-0">
                <span className="text-primary-foreground font-bold text-sm">🏭</span>
              </div>
              {!sidebarCollapsed && (
                <div className="overflow-hidden">
                  <h1 className="font-bold text-sm truncate">Seguridad Industrial</h1>
                  <p className="text-xs text-muted-foreground truncate">Sistema SST</p>
                </div>
              )}
            </div>

            {/* Navigation */}
            <nav className="flex-1 p-3 space-y-2">
              <SidebarItem
                icon="👷"
                label="Empleados"
                active={view === 'empleados'}
                collapsed={sidebarCollapsed}
                onClick={() => setView('empleados')}
              />
              <SidebarItem
                icon="🚨"
                label="Incidentes"
                active={view === 'incidentes'}
                collapsed={sidebarCollapsed}
                onClick={() => setView('incidentes')}
              />
            </nav>

            {/* Toggle button */}
            <div className="p-3 border-t border-border">
              <button
                onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
                className="w-full flex items-center justify-center p-2 rounded-lg hover:bg-secondary transition-colors"
                title={sidebarCollapsed ? 'Expandir' : 'Colapsar'}
              >
                {sidebarCollapsed ? '→' : '← Colapsar'}
              </button>
            </div>

            {/* User info */}
            <div className="p-4 border-t border-border">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                  <span className="text-xs font-bold">👤</span>
                </div>
                {!sidebarCollapsed && (
                  <div className="overflow-hidden">
                    <p className="text-sm font-medium truncate">Usuario Demo</p>
                    <p className="text-xs text-muted-foreground">Administrador</p>
                  </div>
                )}
              </div>
            </div>
          </aside>

          {/* Main content */}
          <main className="flex-1 overflow-auto">
            {/* Top bar */}
            <header className="bg-card border-b border-border px-6 py-4 flex items-center justify-between">
              <h2 className="text-xl font-bold">
                {view === 'empleados' && '👷 Gestión de Empleados'}
                {view === 'incidentes' && '🚨 Registro de Incidentes'}
              </h2>
              <div className="text-sm text-muted-foreground">
                {new Date().toLocaleDateString('es-ES', { 
                  weekday: 'long', 
                  year: 'numeric', 
                  month: 'long', 
                  day: 'numeric' 
                })}
              </div>
            </header>

            {/* Content */}
            <div className="p-6">
              {view === 'empleados' && <Empleados />}
              {view === 'incidentes' && <Incidentes />}
            </div>
          </main>
        </div>
      </QueryClientProvider>
    </trpc.Provider>
  );
}

function SidebarItem({ icon, label, active, collapsed, onClick }: {
  icon: string;
  label: string;
  active: boolean;
  collapsed: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all ${
        active 
          ? 'bg-primary/20 text-primary border border-primary/30' 
          : 'hover:bg-secondary text-muted-foreground hover:text-foreground'
      }`}
      title={collapsed ? label : undefined}
    >
      <span className="text-lg flex-shrink-0">{icon}</span>
      {!collapsed && <span className="text-sm font-medium truncate">{label}</span>}
      {active && !collapsed && (
        <div className="ml-auto w-1.5 h-1.5 rounded-full bg-primary flex-shrink-0" />
      )}
    </button>
  );
}
